class Pessoa {
  String ocupacao;
  String nome;
  String genero;
  int idade;

  public void setOcupacao(String x) {
    ocupacao = x;
  }

  public String getOcupacao() {
    return ocupacao;
  }

  public void setNome(String x) {
    nome = x;
  }

  public String getNome() {
    return nome;
  }

  public void setGenero(String x) {
    genero = x;
  }

  public String getGenero() {
    return genero;
  }

  public void setIdade(int x) {
    idade = x;
  }

  public int getIdade() {
    return idade;
  }

}